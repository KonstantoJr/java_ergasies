package spaceships;
import java.awt.Color;
public class SpaceshipBeta extends Spaceship{

	public SpaceshipBeta() {
		super(20, "Beta" , Color.YELLOW , 300);
	}

}
