package spaceships;

import java.awt.Color;

public class SpaceshipZero extends Spaceship{
	
	public SpaceshipZero(){
		super(5, "Zero" , Color.ORANGE , 100);
	}
	
}
