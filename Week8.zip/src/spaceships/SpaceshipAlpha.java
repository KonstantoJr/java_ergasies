package spaceships;
import java.awt.Color;
public class SpaceshipAlpha extends Spaceship{
	public SpaceshipAlpha() {
		super(10 , "Alpha" , Color.BLUE , 200);
	}

}
