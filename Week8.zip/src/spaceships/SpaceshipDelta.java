package spaceships;

import java.awt.Color;

public class SpaceshipDelta extends Spaceship{

	public SpaceshipDelta() {
		super(40, "Delta" , Color.CYAN , 500);
	}

}
