package spaceships;

public interface Navigation {
	int moveUp();
	int moveDown();
	int moveLeft();
	int moveRight();
}
