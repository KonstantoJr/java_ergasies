package spaceships;

import java.awt.Color;

public class SpaceshipGama extends Spaceship{

	public SpaceshipGama() {
		super(30, "Gama" , Color.magenta , 400);
	}
}
